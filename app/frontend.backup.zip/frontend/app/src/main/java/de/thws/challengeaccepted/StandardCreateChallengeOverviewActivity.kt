package de.thws.challengeaccepted

class StandardCreateChallengeOverviewActivity {
}