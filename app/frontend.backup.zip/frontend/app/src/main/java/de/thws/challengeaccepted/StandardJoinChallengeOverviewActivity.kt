package de.thws.challengeaccepted

class StandardJoinChallengeOverviewActivity {
}