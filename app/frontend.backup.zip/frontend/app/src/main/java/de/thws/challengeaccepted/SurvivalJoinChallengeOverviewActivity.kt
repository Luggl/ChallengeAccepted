package de.thws.challengeaccepted

class SurvivalJoinChallengeOverviewActivity {
}