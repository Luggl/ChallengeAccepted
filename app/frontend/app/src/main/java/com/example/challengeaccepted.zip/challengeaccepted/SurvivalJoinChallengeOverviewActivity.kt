package com.example.challengeaccepted

class SurvivalJoinChallengeOverviewActivity {
}