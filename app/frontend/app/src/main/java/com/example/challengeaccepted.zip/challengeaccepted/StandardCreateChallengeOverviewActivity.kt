package com.example.challengeaccepted

class StandardCreateChallengeOverviewActivity {
}