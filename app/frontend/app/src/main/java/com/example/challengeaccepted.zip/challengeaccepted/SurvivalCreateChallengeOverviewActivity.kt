package com.example.challengeaccepted

class SurvivalCreateChallengeOverviewActivity {
}