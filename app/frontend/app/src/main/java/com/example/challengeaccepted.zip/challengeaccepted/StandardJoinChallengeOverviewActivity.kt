package com.example.challengeaccepted

class StandardJoinChallengeOverviewActivity {
}